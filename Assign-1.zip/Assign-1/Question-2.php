<?php 
$a = '<h1>Who';//first 
$b = 'am I!</h1>';//second 
$c = $a." ".$b;// Concatenation 
  
echo " $c\n ";//Printing 
?> 