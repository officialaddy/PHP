<?php
$x = 3; // global 

function test() {
	 $x = 2; // local 
    echo "<p>x inside function is: $x</p>";
} 
test();

echo "<p>x outside function is: $x</p>";

?>