<?php
$fcolor = "yellow";
switch ($fcolor) {
    case "yellow":
        echo "Yellow is your favorite color!";
        break;
    case "red":
        echo "Red is your favorite color!";
        break;
    case "green":
        echo "Green is your favorite color!";
        break;
    default:
        echo "Your favorite color is neither yellow, red, nor green!";
}
?>