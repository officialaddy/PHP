<html>
    <body>
        <?php
    if(!empty($error_msg)){
        ?>
    <p style="color:red"><?php echo $error_msg;?></p>
    <?php
    }
    ?>
        
      <form method="post" action="indexx.php">   
    <fieldset>Form
        <br>
    <legend>Sign-up</legend>
    <label>First name: </label><input type="text" name="fname" placeholder="First Name" value="<?php echo @$fname;?>"><br><br>
        
    <label>Last name: </label><input type="text" name="lname" placeholder="Last Name" value="<?php echo @$lname;?>"><br><br>
        
    <label>Gender: </label><input type="radio" name="gender" value="male" >Male<input type="radio" name="gender" value="female" >Female <br><br>
        
    <label>State: </label><select  name="state" value="<?php echo @$state;?>">
        <option></option>
        <option>Assam</option>
        <option>Goa</option>
        <option>Sikkim</option>
        <option>Tripura</option>
        </select>   <br><br>
        
        <label>Phone number: </label><input type="text"  name="number" placeholder="+91-0000000000" 
        value="<?php echo @$number;?>"> <br><br>
        
        <label>Password: </label><input type="password" name="pass" value="<?php echo @$pass;?>"> <br><br>
        
        <label>Confirm Password: </label><input type="password" name="cpass" value="<?php echo @$cpass;?>"> <br><br>
        
       <input type="checkbox" name="checkbox"> <label>I agree with terms and conditions</label> <br><br>
        
        <input type="submit" value="submit">
        </fieldset>
        </form>
    </body>
        
  

</html>
