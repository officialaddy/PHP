<?php

$fname=$_POST['fname'];
$lname=$_POST['lname'];
$gender=$_POST['gender'];
$state=$_POST['state'];
$number=$_POST['number'];
$pass=$_POST['pass'];
$cpass=$_POST['cpass'];
$checkbox=$_POST['checkbox'];

if(empty($fname)){
    $error_msg="First name should not be empty";
}

else if($fname>12){
    $error_msg="First name should be greater than 12";
}

else if(empty($lname)){
    $error_msg="Last name should not be empty";
}

else if($lname>12){
    $error_msg="Last name should be greater than 0";
}

else if(empty($gender)){
    $error_msg="Gender should not be empty";
}
else if(empty($state)){
    $error_msg="State should not be empty";
}

else if(empty($number)){
    $error_msg="Number should not be empty";
}

else if(!is_numeric($number)){
    $error_msg="Number should be in numbers";
}

else if($number<10&&$number>10){
    $error_msg="Number should be equal to 10";
}

else if(empty($pass)){
    $error_msg="Password should not be empty";
}

else if($pass<10){
    $error_msg="Password length should not be greater than 10";
}

else if(empty($cpass)){
    $error_msg="Confirm Password should not be empty";
}

else if(!($pass==$cpass)){
    $error_msg="Password should be equal of confirm password";
}

else if(empty($checkbox)){
    $error_msg="click the Checkbox";
}

else{
    $error_msg='';
}

if($error_msg!=''){
    include('ass2.php');
}

?>