<html>
<body>
    <table style="width:250px">
   
        <?php
    
    for($row=1;$row<=8;$row++){
        
        echo"<tr>";
        
        for($col=1;$col<=8;$col++){
            
            $all=$row+$col;
            
            if($all%2==0){
                
                echo"<td height=30px width=30px bgcolor=green ></td>";
            }
            else{
                echo"<td height=30px width=30px bgcolor=blue</style ></td>";
            }
        }
        echo"</tr>";

    }
    ?>
    
    </table>
    <br>
    <a href="q2.php">Next question</a>
    </body>
</html>