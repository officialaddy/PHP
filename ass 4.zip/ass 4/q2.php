<html>
<body >
    <table width="250px" border=2px  cellpadding="5" cellspacing="5">
    <?php
        for($row=1;$row<=6;$row++){
            
            echo"<tr>";
            
            for($col=1;$col<=5;$col++){
                
                $all=$row*$col;
                
                echo"<td>".$row."*".$col."=".$all."</td>";
                
            }
            echo"</tr>";
        }
    ?>
    
    </table>
    <br>
     <a href="q3.php">Next question</a>
    </body>
</html>