<html>

<body>
<?php
$value="level";

if($value==strrev($value)){
    echo"<b> LEVEL </b> is a palindrome word";
}
else{
    echo"Not palindrome";
}
?>
    <br> <br>
    <a href="q4.php">Next question</a>
    </body>
</html>