<?php
function prime($n)
{
 for($i=2; $i<$n; $i++)
   {
      if($n %$i ==0)
	      {
		   return false;
		  }
    }
  return true;
   }
$a = prime(3);
if ($a==0)
echo 'This is not a Prime Number.'."\n";
else{
echo 'This is a Prime Number.'."\n";
}
?>
<br>
<br>
<a href="q5.php">Next question</a>