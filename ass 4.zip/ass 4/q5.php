<?php
$value="khaYati waLia";

echo $value." This is simple text<br><br><br>";
echo strtoupper($value)." All strings are in Uppercase<br><br>";
echo strtolower($value)." All strings are in Lowercase<br><br>";
echo ucfirst($value)." First letter in Uppercase<br><br>";
echo ucwords($value)." First letter of all words in Uppercase";
?>
<br>
<br>
<a href="q6.php">Next question</a>