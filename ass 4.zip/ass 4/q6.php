<?php
 $value="khayatiwalia09@gmail.com";

     echo substr($value,-3)."<br><br>It is only showing last three characters of a string.";
?>
<br>
<br>
<a href="q7.php">Next question</a>