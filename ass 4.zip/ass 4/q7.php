<?php

$temp=array(78, 60, 63, 68, 71, 68, 73, 85, 66, 64, 76, 63, 75, 81, 73, 68, 64, 73, 72, 65, 74, 62, 64, 65, 64, 68, 73, 75, 79, 73);

$count=count($temp);

$sum=array_sum($temp);

$avg=$sum/$count;

echo "Average Temperature is ". $avg . "<br><br>";

sort($temp);

for($i=0;$i<5;$i++){
    
    echo $temp[$i].", ";
    
}
echo " this is the list of five lowest temperatures.<br><br>";


rsort($temp);
for($i = 0; $i < 5; $i++){
 
    
    echo $temp[$i].", ";
}
echo " this is the list of five higest temperatures.<br>";
?>