<?php
include('conn.php');
?>

<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<style type="text/css">
		label, legend{
             color: #fff;
		}
		
	</style>
</head>
<body style="background-color: black;">
<form method="POST">
	<fieldset style="width: 400px; background-color: brown;">
		<legend>Register</legend>
		<label>First Name:</label>
		<input type="text" name="fn" placeholder="First Name" maxlength="12"><br><br>
		<label>Last Name:</label>
		<input type="text" name="ln" placeholder="Last Name" maxlength="12"><br><br>
		<label>Gender:</label>
		<input type="radio" name="gd" class="q" value="Male">Male
		<input type="radio" name="gd" class="q" value="Female">Female<br><br>
		<label>Phone No:</label>
		<input type="tel" name="pn" placeholder="+91-0000000000" maxlength="10"><br><br>
		<label>State</label>
		<select style="color: #000;" name="sct">
			<option style="color: #000;" value="">select</option>
			<option style="color: #000;" value="Assam">Assam</option>
			<option style="color: #000;" value="Goa">Goa</option>
			<option style="color: #000;" value="Sikkim">Sikkim</option>
			<option style="color: #000;" value="Tripura">Tripura</option>
		</select><br><br>
		<label>Password</label>
		<input type="Password" style="color: #000;" name="pss" maxlength="10"><br><br>
		<label>Confirm Password</label>
		<input type="Password" style="color: #000;" name="cpss" maxlength="10"><br><br>
		<input type="checkbox" name="agr">
		I agree with terms and conditions<br><br>
		<input style="color: #000;" type="submit" name="submit" value="Submit">
	</fieldset>
</form>
</body>
</html>



<?php
if(isset($_POST['submit']))
{
$fn=$_POST['fn'];
$ln=$_POST['ln'];
$gd=$_POST['gd'];
$pn=$_POST['pn'];
$sct=$_POST['sct'];
$pss=$_POST['pss'];
$cpss=$_POST['cpss'];
$agr=$_POST['agr'];
if(empty($fn) || empty($ln) || empty($gd) || empty($pn) || empty($sct) || empty($pss) || empty($cpss) || empty($agr))
{
	echo "<script>alert('Fill all the fields')</script>";
}
elseif(!is_numeric($pn)){
	echo "<script>alert('provide phone number in numeric only.')</script>";
}
elseif($pss!=$cpss){
echo "<script>alert('provide same Password.')</script>";	
}
$sql="INSERT INTO ans (fn,ln,gd,pn,sct,pss,cpss) VALUES ('$fn','$ln','$gd','$pn','$sct','$pss','$cpss')";
if($conn->query($sql)===TRUE){
	echo"done";
}
else{
	echo"error".$conn->error;
}
}
?>