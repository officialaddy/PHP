<?php
$servername="localhost";
$username="root";
$password="navdeep1";
$db="assig-2";
$conn= new mysqli($servername,$username,$password,$db);
if ($conn->connect_error) {
	echo "Failed" . $conn->connect_error;
}
else{
	echo "successful";
}
?>