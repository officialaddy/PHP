<?php

if(isset($_POST['submit'])){
    $lp=$_POST['lp'];
    $dp=$_POST['pd'];
    
    
    function finals(){
        $res=$lp*$dp;
    $fres=$res*0.01;
        echo "$fres";
    }
}
    
?>