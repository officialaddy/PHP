<?php
$temp=array(78, 60, 62, 68, 71, 68, 73, 85, 66, 64, 76, 63, 75, 76, 73, 68, 62, 73, 72, 65, 74, 62, 62, 65, 64, 68, 73, 75, 79, 73);
    foreach($temp as $t){
        $count=count($temp);
        $sum=0;
            $sum+=$t;
            $avg=$sum/$count;
        echo"AVERGAE IS " .$avg;
        
    }
echo"<br>";
for($x=0;$x<5;$x++);
echo"$x";
?>