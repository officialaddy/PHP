<?php
$asso=array("Sophia"=>"31","Jacob"=>"41","William"=>"39","Ramesh"=>"40");
ksort($asso);
print_r($asso);
echo"<br>";
    arsort($asso);
print_r($asso);

echo"<br><br>";


$a2=array (4=>"white",6=>"green",11=>"red");
print_r(array_merge($asso,$a2));
echo"<br>";
print_r(array_slice($a2,1,2));
?>