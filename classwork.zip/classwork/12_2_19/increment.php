<?php
$x="6";
echo $x++;
echo ++$x;
echo --$x;
echo $x--;
?>