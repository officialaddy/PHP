<?php
require("connectpdo.php");
?>
<html>
<head></head>
    <body>
    <form action="indexpdo.php" method="post">
       First Name: <input type="text" name="fname"><br><br>
        Last Name:<input type="text" name="lname"><br><br>
        Email:<input type="email" name="email"><br><br>
        <input type="submit" value="submit" name="submit"><br><br>
        </form>
    
    </body>
</html>
<?php

if(isset($_POST['submit'])){
$fname=$_POST['fname'];
$lname=$_POST['lname'];
$email=$_POST['email'];
    
try{
    $sql="insert into register(firstname,lastname,email) values ('$fname','$lname','$email')";
    $conn->exec ($sql);
    echo "done";
}
catch(PDOException $e){
    echo"Error".$e->getMessage();
}
}
?>