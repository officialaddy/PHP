<?php
   
    function add(){
    $a=$_POST['x'];
    $b=$_POST['y'];
     echo "the sum is ".($a+$b);
}
add();
?>