<html>
<head></head>
<body>
    <form method="post" action="action.php">
    <label>Number 1</label><input type="text" name="x"> 
    <br><br>
    <label>Number 2</label><input type="text" name="y">
        
    <br><br>
    <input type="submit" value="Add">
        </form>
    </body>

</html>
