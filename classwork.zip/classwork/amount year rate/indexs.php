<?php

$amount=$_POST['amount'];
$rate=$_POST['rate'];
$year=$_POST['year'];

if(empty($amount)){
    $error_msg="Investment should not be empty";
}
else if(!is_numeric($amount)){
    $error_msg="Investment should be in numbers";
}
else if($amount<=0){
    $error_msg="Investment should be greater than 0";
}

else if(empty($rate)){
    $error_msg="Interset rate should not be empty";
}
else if(!is_numeric($rate)){
    $error_msg="Interset rate should be in numbers";
}
else if($rate<=0){
    $error_msg="Interset rate should be greater than 0";
}
else if(empty($year)){
    $error_msg="Year should not be empty";
}
else if(!is_numeric($year)){
    $error_msg="Year should be in numbers";
}
else if($year<=0){
    $error_msg="Year should be greater than 0";
}

else{
    $error_msg='';
}
if($error_msg!=''){
    include('interest_amount_form.php');
}

$P=$amount*$rate*$year;
$T=$P/100;
echo $T;

?>