<html>
<head>
    
    </head>
<body>
    <?php
    if(!empty($error_msg)){
        ?>
    <p style="color:red"><?php echo $error_msg;?></p>
    <?php
    }
    ?>
    <form method="post" action="indexs.php">
    <label>Investment Amount:</label>
        <input type="text" name="amount" value="<?php echo @$amount;?>">
        <br>  <br>
        <label>Interest Rate:</label>
        <input type="text" name="rate" value="<?php echo @$rate;?>">
        <br>  <br>
        <label>Number of years:</label>
        <input type="text" name="year" value="<?php echo @$year;?>">
          <br>  <br>
        <input type="submit" value="Calculate">
    </form>
    </body>
</html>