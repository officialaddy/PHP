<?php
$x=array("red","green","blue","yellow","pink","orange","brown");
print_r(array_slice($x,2)); #it will start from index number 2

echo"<br><br>";

$b=array("red","green","blue","yellow","pink","orange","brown");
print_r(array_slice($b,2,3)); #it will start from 2 nd pick three values from 2

echo"<br><br>";

$a[0]="one";
$a[1]="two";
$a[2]="three";
$a[3]="four";
print_r(array_slice($a,2,2)); #array slice by associative arrays
?>