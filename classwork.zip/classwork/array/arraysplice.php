<?php
$a1=array("a"=>"red","b"=>"green","c"=>"yellow","d"=>"orange");
$a2=array("a"=>"purple","b"=>"pink");
print_r(array_splice($a1,0,2,$a2));#0 and 2 means from 0 it will remove 2 values
echo"<br><br>";
print_r($a1);
?>