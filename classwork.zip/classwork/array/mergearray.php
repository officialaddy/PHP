<?php
$a1['khayati']="IMDW";
$a2['khayati']="IMDW-18005";
print_r(array_merge($a1,$a2));

echo"<br>";
$b1['1']="abc";
$b2['1']="xyz";
print_r(array_merge($b1,$b2));
?>