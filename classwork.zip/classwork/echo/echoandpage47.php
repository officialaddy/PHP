<?php
$first_name=$_GET['first_name'];
$last_name=$_GET['last_name'];
?>
<html>
<head>
<title>aa</title>
</head>
<body>

<h2>welcome</h2>
<p> first name: <?php echo $first_name;?></p>
<p> last name: <?php echo $last_name;?></p>


</body>
</html>


