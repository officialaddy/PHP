<?php
$number=65;
if($number%2==0){
    echo " number is even";
}
else{
     echo "number is odd";
}
?>
