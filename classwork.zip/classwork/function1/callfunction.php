<?php

function hello(){
    echo "Hello Everyone!How r u?";
}
hello();
?>