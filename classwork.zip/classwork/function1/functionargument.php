<?php
function maximum($x,$y)
{
    if($x>$y)
    {
        return $x;
    }
    else{
        return $y;
    }
}
$a=32;
$b=42;
$value=maximum($a,$b);
echo "the maximum value is ".$value;
?>