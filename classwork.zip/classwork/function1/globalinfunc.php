<?php
$x=5;
$y=2;
function f1(){
    
    global $x,$y;
    $y=$x+$y;
    // $GLOBALS=$GLOBALS[$x]+$GLOBALS[$x];
}
f1();
echo "$y";
$a="Geogrian";
$b="in canada";
echo "<h1>I study in " .$a. " ".$b;
?>