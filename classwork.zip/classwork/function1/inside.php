<?php


function f1()
{
    $x="hello";
    echo " value inside the function $x <br>";
}


f1();
    
?>