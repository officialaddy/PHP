<?php

$x="hello";
function f1()
{

}


f1();
    echo " outside the function $x";

?>