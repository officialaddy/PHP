<?php

$x="hello";
function f1()
{
    echo " value inside the function $x <br>";
}


f1();
    echo " outside the function $x";

?>