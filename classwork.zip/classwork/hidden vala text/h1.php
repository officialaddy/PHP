<html>
<body>
    <form action="h2.php" method="post">
    Num1: <input type="text" name="num1"> 
        <button type="submit" name="submit" >Continue</button>
    
    </form>
    </body>
</html>