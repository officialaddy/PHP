<html>
<body>
    <form action="h3.php" method="post">
    Num2: <input type="text" name="num2">
       <input type="hidden" value="<?php echo $_POST['num1'];?>" name="num1">
        <button type="submit" name="submit">Continue</button>
    
    </form>
    </body>
</html>