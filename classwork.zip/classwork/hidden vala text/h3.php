<html>
<body>
    <form action="h4.php" method="post">
    Num3: <input type="text" name="num3">
       <input type="hidden" value="<?php echo $_POST['num1'];?>" name="num1">
       <input type="hidden" value="<?php echo $_POST['num2'];?>" name="num2">
       <button type="submit" name="submit" value="Continue">Continue</button>
    
    </form>
    </body>
</html>