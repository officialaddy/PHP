<?php
$n1=$_POST['num1'];
$n2=$_POST['num2'];
$n3=$_POST['num3'];
echo "Sum: ".($n1+$n2+$n3);
?>
