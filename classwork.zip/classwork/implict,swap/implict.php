<?php

function power($a,$b=2){
    
    if($b==2){
        return $a*$a;
    }
    
    $value=1;
    for($i=0;$i<$b;$i++)
    {
        $value*=$a;
    }
    return $value;
}
$v1=power(5);
$v2=power(4,4);
echo " $v1 <br>";
echo " $v2 <br>";
?>