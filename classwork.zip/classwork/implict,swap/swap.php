<?php
function swap(&$a,&$b){
$c=$a;
$a=$b;
$b=$c;
echo"a =$a<br>";
echo"b= $b<br>";
    }

 $a=4;
$b=8;
echo "outside<br>";
echo "a is $a<br>";
echo "b is $b<br>";

swap($a,$b);


?>