<?php

for($x=1;$x<=5;$x++)
{
    echo "this is number $x <br>";
}
?>