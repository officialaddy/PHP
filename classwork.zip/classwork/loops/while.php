<?php
$y=1;
while($y<=5){
    echo"This is number $y <br>";
    $y++;
}
?>