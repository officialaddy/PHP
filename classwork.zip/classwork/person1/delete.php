<?php
	include('connect.php');
	
	$msg="";
	$delete_record=$_GET['delete'];
	
	$sql="delete from ass where id=$delete_record";
	
	if ($conn->query($sql) === TRUE) {
    $msg="Record deleted successfully";
	include('view.php');
	exit();
	} else {
    echo "Error deleting record: " . $conn->error;
		}
?>