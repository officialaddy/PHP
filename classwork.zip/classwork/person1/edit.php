<?php
	include('connect.php');
	
	$edit_record=$_GET['edit'];
	
	$sql="select * from register where id=$edit_record";
	$result=$conn->query($sql);
	if($row=$result->fetch_assoc())
	{
		$u_id=$row['id'];
		$u_fname=$row['firstname'];
		$u_lname=$row['lastname'];
		$u_email=$row['email'];
		$u_image=$row['image'];
		
	}
?>
<html>
	<head>
	
	</head>
	<form action="edit.php?edit_rec=<?php echo $u_id ?>" method="post" class="form-group">
		<h1>Update Registeration form</h1>
			Name:<input type="text" name="u_fname" value="<?php echo $u_fname?>"><br><br>
			Last Name:<input type="text" name="u_lname" value="<?php echo $u_lname?>"><br><br>
			Email:<input type="text" name="u_email" value="<?php echo $u_email?>"><br><br>
			
			<input type="submit" value="update" name="update">
		</form>
</html>
<?php
	if(isset($_POST['update']))
	{
		$edit_rec1=$_GET['edit_rec'];
		
		$p_fname=$_POST['u_fname'];
		$p_lname=$_POST['u_lname'];
		$p_email=$_POST['u_email'];
		
		$query="update register set firstname='$p_fname',lastname='$p_lname',email='$p_email' where id=$edit_rec1";
		
		if ($conn->query($query) === TRUE) {
		echo "<script>alert('Record updated successfully')</script>";
		header("location: view.php");
		} else {
			echo "Error updating record: " . $conn->error;
			}
	}
?>