<?php
	include('connect.php');
?>
<html>
	
	<body>	
		<H1>RECORD</H1>
		<table border="1" class="table table-hover">
			<tr>
				<th>ID</th>
				<th>FIRST NAME</th>
				<th>lAST NAME</th>
				<th>EMAIL</th>
				<th>DELETE</th>
				<th>UPDATE</th>
			</tr>
			<?php
				$sql="select * from ass";
				$result=$conn->query($sql);
				$i=1;
				if($result->num_rows>0)
				{
					while($row=$result->fetch_assoc())
					{
					
					?>
						<tr>
				            <td><?php echo $i;$i++; ?></td>
							<td><?php echo $row['fname']; ?></td>
							<td><?php echo $row['lname']; ?></td>
							<td><?php echo $row['email']; ?></td>
							
							
							<td align="center"><a href="delete.php?delete=<?php echo $row['id']?>"><img src="icon/x-button.png"></a></td>
							<td align="center"><a href="edit.php?edit=<?php echo $row['id']?>"><img src="icon/edit.png"></a></td>
							
							
						</tr>
					<?php
					}
				}
				else{
					echo "0 result";
				}
			?>
		</table>
	
  </body>
</html>