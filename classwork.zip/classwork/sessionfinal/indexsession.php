<html>
<head>
</head>
<body>
    <form action="validate.php" method="post">
    Username: <input type="text" name="user"><br>
    Password: <input type="password" name="pass"><br>
    <input type="submit" name="login" value="Log-in">
    </form>
</body></html>