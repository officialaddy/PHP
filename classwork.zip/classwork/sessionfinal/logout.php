<?php
session_start();
session_destroy();
echo"Try again <a href='indexsession.php'>login</a>";
?>