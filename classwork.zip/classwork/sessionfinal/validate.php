<?php
$myuser="abc@gmail.com";
$mypass="12345";
if(isset($_POST['login']))
{
$user=$_POST['user'];
$pass=$_POST['pass'];
    
    if($user==$myuser && $pass==$mypass)
    { 
    session_start();
        $_SESSION['user']=$user;
        include("welcome.php");
    }
    else{
        echo"<script>alert('user name os password is invalid')</script>";
        include("indexsession.php");
        exit();
        }
    }
?>