<?php
error_reporting(0);
session_start();
echo"welcome"."$user";
echo" <a href='logout.php'>Logout</a>";
?>