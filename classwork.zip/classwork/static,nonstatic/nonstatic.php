<?php
function ns(){
$value=4;
    $value+=2;
    return $value;
}
ns();
ns();
ns();
ns();
ns();
ns();
echo ns();
?>