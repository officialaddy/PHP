<?php
function ns(){
   static $value=0;
    $value+=1;
    return $value;
}
ns();
ns();
ns();
echo ns();
?>