<html>
<head>
    
    </head>
<body>
<?php

    $a="6";
    $b="3";
    $c=$a+$b;
    echo $c;
    
?>
    <br>
<br>
    <?php
    $d="3";
    $e="2";
    echo $d*$e;
    ?>
    
     <br>
<br>
    <?php
   
    $f="36";
    $g="2";
    echo $f/$g;
    ?>
    
     <br>
<br>
    <?php
    
    $d="3";
    $e="2";
    echo $d-$e;
    ?>
    
    </body>
</html>