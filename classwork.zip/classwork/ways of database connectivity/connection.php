<?php
$servername="localhost";
$username="root";
$password="";
$database="hello";

$sql= new mysqli($servername,$username,$password,$database);
if($sql->connect_error){
    echo"Failed";
}
else{
    echo "Done";
}
    ?>