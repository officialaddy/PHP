<?php
include('connection.php');
?>
<html>
<body>
    <form action="insert.php" method="post">
        First name:<input type="text" name="fname">
        Last name:<input type="text" name="lname">
        Roll no:<input type="text" name="roll">
        Class:<input type="text" name="class">
    <button type="submit" name="submit">Submit</button>
    </form>
    </body>

</html>
<?php
if(isset($_POST['submit'])){
    $fn=$_POST['fname'];
    $ln=$_POST['lname'];
    $rn=$_POST['roll'];
    $cl=$_POST['class'];
    $query="insert into tables(fname, lname, rollno, class) values('$fn','$ln','$rn','$cl')";
    if($sql->query($query)==true)
    {
        echo "All done";
    }
    else
    {
        echo" Some error";
    }
}
?>