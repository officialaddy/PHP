<html>
<?php
   $servername="localhost";
       $username="root";
       $password="";
       $dbname="hello";
       $conn= new mysqli($servername,$username,$password,$dbname);
    if($conn->connect_error)
    {
        echo ("Wrong");
    }
    else
    {
        echo("Yes");
    
    }
?>
</html>