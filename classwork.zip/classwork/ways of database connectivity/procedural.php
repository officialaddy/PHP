<html>
<?php
   $servername="localhost";
       $username="root";
       $password="";
       $dbname="hello";
       $conn=mysqli_connect($servername,$username,$password,$dbname);
    if($conn->connect_error)
    {
        die("connection failed".mysqli_connect_error());
    }
    else
    {
        echo("Yes");
    
    }
?>
</html>