<?php
function familyName($fname,$year="1789",$age="16") 
{
    echo "$fname Walia born in $year having $age years old.<br>";
}
familyName("Jani","1982");
familyName("Hege","1942","54");
familyName("Stale");
familyName("Kai Jim","1982","54");
familyName("Borge","1789");
?> 
