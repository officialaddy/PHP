<html>
<body>

<?php
$x = 100;  
$y = 50;

if ($x !== 100) {
    echo "Hello world!";
}
    else{
        echo"wrong";
    }
?>  

</body>
</html>
