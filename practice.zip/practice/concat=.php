<?php
$a="hello ";
$b="dears ";
echo $a.=$b."<br>";
echo $a;
?>