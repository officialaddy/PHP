<?php
$servername="localhost";
$username="root";
$password="";
$database="mst";
$sql= new mysqli($servername,$username,$password,$database);
if($sql->connect_error){
    echo"failed";
}
else{
    echo"done";
}
?>