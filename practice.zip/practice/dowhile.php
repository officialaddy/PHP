<?php
$x=1;
do{
 echo $x;
    $x++;
}

while($x<19);
?>