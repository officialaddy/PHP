<?php

function power($a,$b=3){
    
    if($b==3){
        return $a*$a;
    }
    
    $value=1;
    for($i=0;$i<$b;$i++)
    {
        $value*=$a;
    }
    return $value;
}
$v1=power(5);
$v2=power(2,2);
echo " $v1 <br>";
echo " $v2 <br>";
?>