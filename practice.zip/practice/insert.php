<?php
include('connection.php');
?>
<html>
<body>
<form method="post" action="insert.php">
    First name<input type="text" name="f1">
    Last name<input type="text" name="l1">
    email<input type="email" name="e1">
    <button type="submit" name="submit">Click</button>
       </form>
       </body>
</html>
<?php
if(isset($_POST['submit']))
{
    $f=$_POST["f1"];
    $l=$_POST["l1"];
    $e=$_POST["e1"];
    $query="INSERT INTO mstexam(fname,lname,email) values ('$f','$l','$e')";
    if($sql->query($query)==true){
        echo"done";
    }
    else{
        echo"error".$query."<br>".$sql->error;
    }
}
?>