<?php
$x=3;
function local(){
    global $x;
    echo"in the function $x";
}
echo"outside the function $x";
local();
?>
