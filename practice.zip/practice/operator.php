<?php
$x=5;
$y;
$y=$x;
echo $y;
?>