<?php
function ss(){
     $v=1;
    $v+=1;
  return $v;  
}
echo ss();
echo ss();
echo ss();