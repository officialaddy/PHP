<?php
echo strlen("Hello dear");
?>
<br>
<?php
echo str_word_count("Hello everyone!How are you ?");
?>
<br>
<?php
echo strrev("Khayati");
?>
<br>
<?php
echo strpos("hello everyone!how r u?","everyone");
?>
<br>
<?php
echo str_replace("world","dolly","hello world how r u?");
?>