<?php
$x=1;
switch($x){
        case 1:
        echo "one one one";
        break;
        case 2:
        echo "two";
        break;
        case 3:
        echo "three";
        break;
        default:
        echo "4567890";
        break;
     
}
?>