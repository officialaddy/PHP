<?php
$x=1;
while($x<10){
    echo $x;
    $x++;
    
}
?>