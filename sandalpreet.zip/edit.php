<?php
include 'dblicense.php';
include 'header.php';
$license= $_GET['license'];
?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit </title>
</head>
<body>
<form method="POST" enctype="multipart/form-data"> 
	<fieldset>
		<legend>User Name</legend>
		<input type="text" name="uname">
		<legend>Age(in years)</legend>
		<input type="number" name="age">
		<legend>Phone</legend>
		<input type="phone" name="phn">
		<legend>Address</legend>
		<textarea name="address" rows="10" cols="30"></textarea>
		<input type="file" name="image" value="">
		<br><br>
		<input type="hidden" name="lno" value="<?php echo $license; ?>">
		
		<button type="submit" name="submit">Update</button>
	</fieldset>
</form>
</body>
</html>
<?php
if (isset($_POST['submit'])) 
{
	$lno=$_POST['lno'];
	$uname=$_POST['uname'];
	$age=$_POST['age'];
	$phn=$_POST['phn'];
	$address=$_POST['address'];
	$filename=$_FILES['image']['name'];
	$tempname=$_FILES['image']['tmp_name'];
	$folder='images/'.$filename;
	move_uploaded_file($tempname,$folder);
	if ($uname=="" || $age=="" || $phn=="" ||$address=="") 
	{
		echo "<script> alert('All fields must be filled.')</script>";
	}
	else
	{
	$sql6="UPDATE registration  SET uname='$uname',age='$age',phn='$phn',address='$address',image='$folder'  WHERE lno='$lno'";
	$data=mysqli_query($conn,$sql6);
	if ($data) {
		echo "<script> alert('Successfully Updated')</script>";
		header('location:listlicense.php');
	}
	else{
		echo $conn->error;
	}
}
}
include 'footer.php';
?>