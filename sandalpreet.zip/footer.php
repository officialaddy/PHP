<style type="text/css">
	.li{
		float: left;
		font-size: 60%;
		width: 7%;
		padding: 0;
		width: 4%;	
	}
</style>

<footer>
	<div class="divv" style="height: 50px; display: flex;">
<ul>
	<li class="li">Home</li>
	<li class="li">About</li>
	<li class="li"><a href="listlicense.php">License</a></li>
	<li class="li">Contact</li>
	
</ul>
<img src="fb.png" style="height: 30px; width: 30px;margin: 1%;">
	<img src="twitter.png" style="height: 30px; width: 30px;margin: 1%;">
</div>
<center>&copySandalpreet Kaur IMDW ALL Rights Reserved.</center>
</footer>
