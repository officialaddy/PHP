<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.divv{
			height: 100px;
			width: 100%;
			background-color:  #556670;
		}
			ul{
				margin: 0;
			padding: 0%;
			list-style-type: none;
			width: 100%;
			height: auto;
			color: #A4DFCD;
			font-size: 165%;
	}
	li{
		margin-top: 2%;
				float: right;
			padding: 1%;
			width: 10%;
			height: auto;
			text-decoration-style: none;
		}
		li:hover{
			color: darkgray ;
		}
		a{
			text-decoration: none;
			color:#A4DFCD;
		}
		a:hover{
			color: darkgray;

		}
	</style>
</head>
<body>
	<div class="divv">
<ul>
	<li>Home</li>
	<li>About</li>
	<li><a href="listlicense.php">License</a></li>
	<li>Contact</li>
</ul>
</div>
</body>
</html>