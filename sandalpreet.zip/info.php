<?php
session_start();
include 'dblicense.php';
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Information</title>
	<style type="text/css">
		form{
			width: 20%;
			margin: auto;
		}
	</style>
</head>
<body>
<form method="POST" action="" enctype="multi/form-data"> 
	<fieldset>	
		<legend>Image</legend>
		<input type="file" name="uploadfile"><br><br>
		<button name="submit2">Submit</button>
	</fieldset>
</form>
</body>
</html>
<?php
if (isset($_FILES["file"]["name"])) 
{
$filename=$_FILES["uploadfile"] ["name"];
$tempname=$_FILES['uploadfile'] ['tmp_name'];
$folder="images/".$filename;
echo $folder;
move_uploaded_file($tempname, $folder);
/*try{
$sql2="INSERT INTO registration (lno,age,phn,address,image) VALUES ('$lno','$age','$phn','$address','$folder') ";
if (mysqli_query($conn,$sql2)) {
	echo "done";
	header("location:login.php");
}
else{
	echo "Error: " . $sql2 . "<br>" .
			$conn->error;
}
}
catch(Excception $e)
{
echo "ERROR: ".$e->getMessage();
}*/
}
?>