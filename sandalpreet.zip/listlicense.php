<?php
session_start();
include 'dblicense.php';
include 'header.php';
if (isset($_POST['user'])) {
	$sql4="SELECT * FROM registration ORDER BY uname";
$data=mysqli_query($conn,$sql4);
}
else if(isset($_POST['lno'])) {
	$sql4="SELECT * FROM registration ORDER BY lno";
$data=mysqli_query($conn,$sql4);
}
else if (isset($_POST['age'])) {
	$sql4="SELECT * FROM registration ORDER BY age";
$data=mysqli_query($conn,$sql4);
}
else if (isset($_POST['phn'])) {
	$sql4="SELECT * FROM registration ORDER BY phn";
$data=mysqli_query($conn,$sql4);
}
else if (isset($_POST['address'])) {
	$sql4="SELECT * FROM registration ORDER BY address";
$data=mysqli_query($conn,$sql4);
}
else if(isset($_POST['search'])) {
	$item=$_POST['item'];
	$sitem=$_POST['sitem'];
		if ($sitem=='lno' && $item !="") 
		{
		$sql5="SELECT * FROM registration where lno='$item'";
		$data=mysqli_query($conn,$sql5);
		}
		else if ($sitem=='uname' && $item !="") {
			$sql5="SELECT * FROM registration where uname='$item'";
		$data=mysqli_query($conn,$sql5);
		}
		else if ($sitem=='age' && $item !="") {
			$sql5="SELECT * FROM registration where age='$item'";
		$data=mysqli_query($conn,$sql5);
		}
		else if ($sitem=='phn' && $item !="") {
			$sql5="SELECT * FROM registration where phn='$item'";
		$data=mysqli_query($conn,$sql5);
		}else if ($sitem=='address' && $item !="") {
			$sql5="SELECT * FROM registration where address='$item'";
		$data=mysqli_query($conn,$sql5);
		}
		else{
			echo "<script>alert('Enter some value.')</script>";
			header("location:listlicense.php");
		}
	}
else{
$sql3="SELECT * FROM registration";
$data=mysqli_query($conn,$sql3);
}	
$rows=mysqli_num_rows($data);
if ($rows !=0)
{
?>
<style type="text/css">
	td{
		border: 1px solid black;
	}
	th{
		border: 1px solid black;
	}
	table{
		width: 50%;
		margin: auto;	
	}
</style>
	<h1 style="text-align:center;">Manage License Data</h1>
	<form method="POST" style="text-align:center;">
		Search for:<input type="text" name="item">
		<select name="sitem">
			<option value="lno">License No.</option>
			<option value="uname">User Name</option>
			<option value="age">Age</option>
			<option value="phn">Phone</option>
			<option value="address">Address</option>
		</select>
		<button name="search">Search</button><br><br>
	<table>
		<tr>
			<th><button name="lno">License No</button></th>
			<th><button name="user">User Name</button></th>
			<th><button name="age">Age(years)</th>
			<th><button name="phn">Phone</th>
			<th><button name="address">Address</th>
			<th>Image</th>
			<th>Action</th>
		</tr>
	
	<?php
	while ($result=mysqli_fetch_assoc($data)) 
	{
	echo "<tr>
			<td>".$result['lno']."</td>
			<td>".$result['uname']."</td>
			<td>".$result['age']."</td>
			<td>".$result['phn']."</td>
			<td>".$result['address']."</td>
			<td><img src='".$result['image']." ' width='100' height='100'></td>
			<td><a href='edit.php?license=$result[lno]'><img src='edit.png'  width='100' height='100'></a></td>
			</tr>";
			
	}
}
else
{
	echo "No records Found.";
}
?>
</table>
</form>
<?php
include 'footer.php';
?>