<?php
session_start();
include 'dblicense.php';
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style type="text/css">
		form{
			width: 20%;
			margin: auto;
		}
	</style>
</head>
<body>
<form action="" method="POST"> 
	<fieldset>
		<legend>User Name</legend>
		<input type="text" name="username">
		<legend>Password</legend>
		<input type="Password" name="password"><br><br>
		<input type="submit" name="submit2">
	</fieldset>
</form>
</body>
</html>
<?php

if(isset($_POST['submit2']))
{
	$usern=$_POST['username'];
	$passw=$_POST['password'];
	try
	{
	$sql3="SELECT * FROM registration where uname='$usern' and pass ='$passw'";
	$result=mysqli_query($conn,$sql3);
	$num=mysqli_num_rows($result);
	if ($num ==1) {
		header('location:license.php');
	}
	else{
		header('location:login.php');
	}
	}
	catch(Exception $e)
	{
	echo "Error: ".$e->getMessage();
	}
}
?>