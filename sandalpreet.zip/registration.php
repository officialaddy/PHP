<?php
include 'dblicense.php';
include 'header.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration</title>
	<style type="text/css">
		form{
			width: 20%;
			margin: auto;
		}
	</style>
</head>
<body>
<form method="POST"  enctype="multipart/form-data"> 
	<fieldset>
		<legend>User Name</legend>
		<input type="text" name="uname">
		<legend>Email</legend>
		<input type="Email" name="email">
		<legend>Password</legend>
		<input type="Password" name="pass">
		<legend>Confirm Password</legend>	
		<input type="Password" name="cpass">
		<legend>License No.</legend>
		<input type="number" name="lno">
		<legend>Age(in years)</legend>
		<input type="number" name="age">
		<legend>Phone</legend>
		<input type="phone" name="phn">
		<legend>Address</legend>
		<textarea name="address" rows="10" cols="30"></textarea>
		<legend>Image</legend>
		<input type="file" name="image2" value=""><br><br>
		<a href="login.php"><button name="submit">Submit</button></a>
	</fieldset>
</form>
</body>
</html>
<?php
session_start();
if (isset($_POST['submit'])) 
{
$uname=$_POST['uname'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$cpass=$_POST['cpass'];
$lno=$_POST['lno'];
$age=$_POST['age'];
$phn=$_POST['phn'];
$address=$_POST['address'];
$filename=$_FILES['image2']['name'];
$tempname=$_FILES['image2']['tmp_name'];
$folder='images/'.$filename;
move_uploaded_file($tempname,$folder);
$sql="INSERT INTO registration (uname,email,pass,cpass,lno,age,phn,address,image) VALUES ('$uname','$email','$pass','$cpass','$lno','$age','$phn','$address','$folder')";
if (mysqli_query($conn,$sql)) 
{
echo "data inserted";
header("location:login.php");
}
else
{
	echo "Can't insert the data."."<br>".$conn->error;
}
}
include 'footer.php';
?>