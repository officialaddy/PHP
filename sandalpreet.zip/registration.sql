-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 21, 2019 at 04:05 PM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `a3`
--

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `uname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL,
  `cpass` varchar(30) NOT NULL,
  `lno` int(255) NOT NULL,
  `age` int(100) NOT NULL,
  `phn` int(10) NOT NULL,
  `address` varchar(900) NOT NULL,
  `image` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`uname`, `email`, `pass`, `cpass`, `lno`, `age`, `phn`, `address`, `image`) VALUES
('Gurjot', 'gur@gmail.com', 'g', 'g', 1, 12, 98789876, 'Patiala', 'images/1.jpg'),
('Arsh', 'arsh@gmail.com', 'a', 'a', 2, 21, 2147483647, 'Ludhiana', 'images/back.jpg'),
('Kirandeep', 'taran@gmail.com', 't', 't', 3, 20, 2147483647, 'Amritsar', 'images/bird.gif'),
('Sandalpreet', 'sandal@gmail.com', 's', 's', 4, 19, 2147483647, 'Patiala', 'images/flower.jpg'),
('Ajay', 'ajay@gmail.com', 'ajay', 'ajay', 5, 20, 2147483647, 'Mohali', 'images/2.jpg'),
('Aditya', 'aditya@gmail.com', 'ad', 'ad', 6, 21, 2147483647, 'Chandigarh', 'images/bg.jpg'),
('Anirudh', 'ANi@gmail.com', 'ani', 'ani', 7, 20, 2147483647, 'Chandigarh', 'images/1.jpg.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
